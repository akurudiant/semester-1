package utsrudianto;

import java.util.Scanner;

public class UtsRudianto {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        
        String katagori;
        double gajiKotor,gajiBersih,potongan,tunjangan,jumlahAnak= 0;
        
        System.out.println("Masukkan Gaji Kotor Pegawai = ");
        gajiKotor = scan.nextInt();
        System.out.println("Masukkan Jumlah Anak Pegawai =");
        jumlahAnak = scan.nextInt();
        
        if (jumlahAnak <=2){
           tunjangan = gajiKotor * 0.2;
           potongan = gajiKotor * 0.05;
        } else {
            tunjangan = gajiKotor * 0.3;
            potongan = gajiKotor * 0.07;
        }
        gajiBersih = gajiKotor + tunjangan -potongan ;
        System.out.println("Tunjangan =" + tunjangan);
        System.out.println("Potongan = " + potongan);
        System.out.println("Gaji Bersih = "+ gajiBersih);
    }
    
}